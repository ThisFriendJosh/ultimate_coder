# Weekly Plan Template

- Objectives
- Key readings
- Build tasks
- Tests & acceptance
- Hardening (perf, security, docs)
- Demo & retro
